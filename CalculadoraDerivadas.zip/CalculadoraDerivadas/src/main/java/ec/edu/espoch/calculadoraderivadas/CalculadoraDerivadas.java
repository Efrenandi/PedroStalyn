
package ec.edu.espoch.calculadoraderivadas;

import ec.edu.espoch.Modelo.Derivada1;
import ec.edu.espoch.Vista.Derivada;

/**
 Efren Andi
 Camila ALama
 Joel Rojel
 */
public class CalculadoraDerivadas {

    public static void main(String[] args) {
        Derivada1 objDerivada1= new Derivada1();
        objDerivada1.equals(true);
        Derivada objDerivada = new Derivada();
        objDerivada.setLocationRelativeTo(null);
        
    }
}
