/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espoch.proyecto;

import io.reactivex.Observable;
import java.util.Scanner;

public class Proyecto {

    public static void main(String[] args) {

        Observable<String> argumentObservable = Observable.create(emitter -> {
            Scanner argumentScanner = new Scanner(System.in);
            System.out.print("Ingrese la expresión algebraica : ");
            String expression = argumentScanner.nextLine();
            emitter.onNext(expression);
            emitter.onComplete();
        });

        long startTime = System.nanoTime();

        argumentObservable
                .map(Proyecto::calculateDerivative)
                .subscribe(System.out::println, Throwable::printStackTrace);

        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        System.out.println("Tiempo de ejecución para el cálculo de derivadas: " + elapsedTime + " nanosegundos");
    }

    private static String calculateDerivative(String expression) {

        String[] terms = expression.split("\\+");
        StringBuilder derivative = new StringBuilder();

        for (String term : terms) {
            if (term.contains("*x^")) {
                // Obtener el coeficiente y el exponente de 'x' en el término
                String[] parts = term.split("\\*x(\\^)?");
                if (parts.length > 0) {
                    try {
                        // Cambiar a Double para manejar fracciones
                        double coefficient = Double.parseDouble(parts[0].trim());
                        int exponent = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 1;

                        // Calcular el nuevo coeficiente y exponente después de la derivada
                        double newCoefficient = coefficient * exponent;
                        int newExponent = exponent - 1;

                        // Construir el término de la derivada
                        if (derivative.length() > 0) {
                            derivative.append(" + ");
                        }
                        derivative.append(newCoefficient).append("*x^").append(newExponent);
                    } catch (NumberFormatException e) {
                        return "Formato incorrecto en la expresión";
                    }
                }
            } else if (term.contains("*x")) {
                // Tratar el caso sin exponente especificado (por ejemplo, 2*x)
                try {
                    // Cambiar a Double para manejar fracciones
                    double coefficient = Double.parseDouble(term.replace("*x", "").trim());

                    // Construir el término de la derivada
                    if (derivative.length() > 0) {
                        derivative.append(" + ");
                    }
                    derivative.append(coefficient);
                } catch (NumberFormatException e) {
                    // Manejar errores de formato
                    return "Formato incorrecto en la expresión";
                }
            }
        }

        if (derivative.length() > 0) {
            return derivative.toString();
        } else {
            return "0";
        }
    }
}

